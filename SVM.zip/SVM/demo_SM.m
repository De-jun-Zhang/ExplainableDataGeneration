
model_I = train(train_label, sparse(double(train_data)),'-s 0 -B 1 -c 30 -q');
%ops.verb=2;model_I = lin_train(cat.tr, sparse(I_tr),ops);
[predicted_label, acc, smn_I.te] = predict(test_label, sparse(double(test_data)), model_I,' -b 1'); 

y=smn_I.te(:,1);
y = y/sum(y);
real_label = test_label;
plotroc(real_label',y')
% legend('middle','Text');
auc = AUC(real_label',y')